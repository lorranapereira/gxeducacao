<?php
require_once("layout/navbar.php");

?>
  <!-- Page Content -->
  <div  class="container">
    <br/>
    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">
      <small style="color:#244c74"> JORNADA DO INVESTIDOR
</small>
    </h1>

    <!-- /.row -->
    <br/>
    <div class="row" style="position:relative;left:-12%;width:118%;box-shadow: 0 0 0.5em gray;">

    <? $atual = $videoAtual;
   // unset($outros[0]['id']); ?>
          <div style="position:relative;width:80%;left:4%;margin:63px;"   >
              <h4 style="color:#244c74;top:1em;"><? echo $atual['titulo']; ?></h4>
              <a href="videoaula2">              
              <? echo  $atual['nome']; ?>
              </a>
          </div>
          </div>          
          <div style="position:relative;width:100%;"  >

            <div style="position:relative;width:100%;font-size:15px;top:4em;"  >
              <h3><? echo $atual['titulo']; ?></h3>
              <p  style="position:relative;width:70%;font-size:15px;top:4em;left:2%;"><? echo $atual['descricao']; ?></p>
            </div>
        </div>
        </div>

        <br/>
        <br/>
        <br/>
        <br/>        
        <br/>
        <br/>
        <h3 class="my-4" style="border-top: 1px solid #244c74; padding:20px;">Videoaulas</h3>
        <div style="position:relative;left:5%;width:95%;" class="row">

        <? $ctd = count($videos); ?>
        <? for ($i=1; $i < $ctd; $i++) {
           ?>
            <a href="proximoVideo?id=<? echo $videos[$i]['id'];  ?>">
              <img class="d-block w-10" style="position:relative;margin:3px;" width="290px;" height="250px;" src="<? echo $videos[$i]['imagem'];?>" alt="Primeiro Slide">
            </a>  

          <?        } ?>
        </div>

    </div>
    <!-- /.row -->
<br/>

  <!-- /.container -->

<?php
require_once("layout/footer.php");

?>