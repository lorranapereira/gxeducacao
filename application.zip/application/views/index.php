<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond&display=swap" rel="stylesheet">
  <link  rel = " stylesheet "  href = " https://unpkg.com/aos@next/dist/aos.css " />

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <!-- Stylesheets -->
  <link href="/css2/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="/css/favicon.ico" type="image/x-icon">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>

  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <title>Gx educação</title>
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Rubik:500&display=swap" rel="stylesheet">
<!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css">

 <!-- <link href="css/modern-business.css" rel="stylesheet"> -->
  <link rel="stylesheet" href="/css/indexstyle.css" >
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Heebo&display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari|Playfair+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body >
    <nav  style="background-color:transparent!important;" class="navbar navbar-expand-lg navbar-light bg-light">
        <img class="logo" style="position:relative;width:15%;" src="/css/gxeduca.png">
        <button type="button" id="button" class="btn btn-info" style="position:relative;border-radius:5%;font-weight:bold;font-size:18px;text-decoration:none;left:70%;margin:10px;"  class="btn btn-primary" data-toggle="modal" data-target="#ExemploModalCentralizado">
            Área do aluno
        </button>
    </nav>

    <div style="position:relative;top:-1em;width:110%;height:32em;background-color:#0d47a1" id="rowtop" class="row">
        <div style="position:relative;margin:20px;" class="col-sm">
            <br/>
            <h1 data-aos="fade-down" data-aos-duration="1000"  style="color:white;font-size:3.5rem;margin:40px;font-weight: bold;" class="titulo" >APRENDA A INVESTIR SEM SAIR DE CASA!</h1>
            <br/>
            <p  class="subtitulo" style="color:white;top:-2em;margin:40px;font-size:1.8rem;">Adquirá e amplie seu conhecimento em investimento, com instrutores especialistas no mercado. 
            Se você quer fazer seu dinheiro trabalhar por você, não perca essa oportunidade!</p>
        </div>
        <div class="col-sm">
        <img  data-aos="fade-left" class="img" data-aos-duration="1000"  style="position:relative;width:120%;height:31.9em;" src="/css/up.jpg" alt="">
        </div>

    </div>
    <div id="rowtop" class="row">
        <div class="col-sm">
        <img style="width:100%;top:1em;height:30em;" src="/css/div2.png">
        </div>
        <div class="col-sm">
            <h1 id="h1div2" style="position:relative;left:30%;width:50%;font-weight:bold;top:2em;">Bem-vindo</h1>
            <p class="pgf"  style="position:relative;top:10em;color:black;">A Gx Educação é uma plataforma de educação continuada, criada pelo grupo Gx, que consiste em fornecer videoaulas sobre 
            investimentos, mercado e bolsa de valores de alta qualidade e de fácil compreensão. ​​​​​​​</p>
        </div>
    </div>
    <div style="position:relative;margin:20px;" id="compra" class="row">
        <div class="col-sm">
            <h1 class="h1div3">ADQUIRÁ CONHECIMENTO EM INVESTIMENTO </h1>
            <p   style="position:relative;color:black;margin:10px;top:5em;">Aprenda os princípios e conceitos para se organizar e criar a disciplina para 
                investimentos, alcançando suas realizações financeiras de forma rápida e consistente, conheça as melhores alternativas de investimento de acordo com o seu perfil de investidor.  ​​​​​​​</p>
           <br/>
         <!--  <h1 class="preco" >R$ 500,00</h1> !-->
           <div style="position:relative;top:5em;margin:20px;" class="row">
                <img style="width:20px;" src="/css/estrela.png">
                <img style="width:20px;" src="/css/estrela.png">
                <img style="width:20px;" src="/css/estrela.png">
                <img style="width:20px;" src="/css/estrela.png">
                <img style="width:20px;" src="/css/estrela.png">

            </div>
            
        </div>
        <div class="col-sm">
            <img style="width:100%;top:1em;height:29em;" src="/css/computer.gif">

        </div>
    </div>
    <div data-aos="flip-left" data-aos-duration="2000" id="bonus" style="position:relative;top:15em;border:1px solid gray;background: rgb(12,199,186);
    background: linear-gradient(90deg, rgba(12,199,186,0.8421743697478992) 8%, rgba(12,23,199,0.8421743697478992) 53%, rgba(12,181,199,0.8421743697478992) 98%);padding-left:20%;height:15em;margin:20px;-webkit-box-shadow: -1px 2px 18px -1px rgba(0,0,0,0.75);
    -moz-box-shadow: -1px 2px 18px -1px rgba(0,0,0,0.75);
    box-shadow: -1px 2px 18px -1px rgba(0,0,0,0.75);
    " class="row">
        <h1 style="position:relative;color:white;left:30%;" class="h1div4">Bônus</h1>
        <p class="pgraf" style="position:relative;top:5em;font-size:2.2rem;color:white;">Além das videoaulas, você ainda ganhará benefícios!</p>

        <div id="benef" style="position:relative;top:15em;left:-20%;padding-left:10em;" class="row">
            <div style="position:relative;left:10%;" class="col-sm">
                <img class="material" src="/css/material.png">
                <p class="titulo1" style="color:black;right:10%;font-size:1.8rem;width:100%;" >Material didático completo</p> 
                <p class="text-center" id="desc1" style="right:20%;font-size:1.5rem;width:70%;">Material didático completo feito pelos melhores profissionais do mercado financeiro.</p>
            </div>
            <div style="position:relative;left:9%;"  class="col-sm">
                <img class="assessor" src="/css/assessor.png">
                <p class="titulo2" style="color:black;right:5%;font-size:1.8rem;">Assessor exclusivo</p> 
                <p class="text-center" id="desc2" style="right:20%;font-size:1.5rem;width:70%;">Um assessor exclusivo que estará a sua disposição para esclarecer qualquer dúvida.</p>
            </div>
        </div>
    </div>

    <div class="row" style="position:relative;height:100%;" >
      <div class="col-lg-4 mb-3" id="logo">

      </div>

    <div id="img2" style="position:relative;background-attachment: fixed;top:49em;  background-size: cover; width:100%;height:50em;background-repeat:no-repeat;  background-position:center center; background-image:url(/css/cad.jpg)" >
    </div> 

   

    <div style="position:relative;width:50%;top:-9em;left:10%;" id="cadastro"  class="col-md-6 col-sm-12 col-xs-12">
        <div class="contact-area">
            <div  class="col-sm">
            <form class="form-signin" action="/index.php/Control/redcadastro" method="POST">


                </div>
            </div>

                <div  id="cad" style="position:relative;top:10em;height:35em;border: 1.7px solid white;
                background: rgb(218,220,238);
                background: linear-gradient(90deg, rgba(218,220,238,0.8421743697478992) 7%, rgba(207,210,222,0.30155812324929976) 98%);
                border-radius:5%;width:100%;">
                <br/>
                <br/>
                <h5 style="position:relative;width:80%;left:10%;color:black;font-size:3rem!important;
                font-family: 'Heebo', sans-serif;color: rgb(2, 148, 255);" class="card-title text-center">
                   Realize seu cadastro!<br/>
                    <?php
                    if ($this->session->flashdata('warning')) {
                    ?>
                        <div class="alert alert-warning text-center" style="margin-top:20px;font-size:1.5rem!important;">
                            <?php echo $this->session->flashdata('warning'); ?>
                        </div>
                        <?php
                    }
                    ?> 
                    <?php
                    if ($this->session->flashdata('success')) {
                    ?>

                        <div class="alert alert-success text-center" style="margin-top:20px;font-size:1.5rem!important;">
                            <?php echo $this->session->flashdata('success'); ?>
                        </div>
                        <?php
                    }
                    ?> 
                </h5>
                  <hr class="my-4">
                  <div class="contact-area">
                    <form   name="contact_form"  class="default-form contact-form" action="sendmail.php" method="post">
                        <div class="row">
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div  class="form-group">
                                    <input style="position:relative;width:100%;left:-15%;font-size:1.8rem!important;" type="text" id="nome" <? if(isset($formindex)) { echo "autofocus"; }?> name="nome" class="form-control" placeholder="Nome" required>

                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input type="text" style="position:relative;left:-1%;font-size:1.8rem!important;width:90%;" id="sobrenome" name="sobrenome" class="form-control" placeholder="Sobrenome" required>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                <input type="email" style="position:relative;left:-7.8%;font-size:1.8rem!important;" id="email" id="email" name="email" class="form-control" placeholder="Email" required>

                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input type="password" style="position:relative;width:100%;left:-15%;font-size:1.8rem!important;" id="senha" name="senha" class="form-control" placeholder="Senha" required>

                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input id="tel" style="position:relative;width:90%;font-size:1.8rem!important;" name="tel" type="text" placeholder="(XX) 9___-_____"  class="tel" required/>
                                </div>
                            </div>
                            <br/>
                            <br/>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group text-center">
                                <br/>
                                <br/>
                                    <button id="enviar" style="position:relative;right:5%;width:60%;" type="submit" class="btn-style-one">Enviar</button>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>                       
                 
            </div>
         </div>  
      </form>    
    </div>
  </div>    
  </div> 
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
   
  <script>
   jQuery("input.tel").mask("(99) 9999-9999?9").focusout(function (event) {  
        var target, phone, element;  
        target = (event.currentTarget) ? event.currentTarget : event.srcElement;  
        phone = target.value.replace(/\D/g, '');
        element = $(target);  
        element.unmask();  
        if(phone.length > 10) {  
            element.mask("(99) 99999-999?9");  
        } else {  
            element.mask("(99) 9999-9999?9");  
        }  
    });
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="/plugins/jquery.js"></script>
    <script src="/plugins/bootstrap.min.js"></script>
    <script src="/plugins/bootstrap-select.min.js"></script>
    <!-- Slick Slider -->
    <script src="/plugins/slick/slick.min.js"></script>
    <!-- FancyBox -->
    <script src="/plugins/fancybox/jquery.fancybox.min.js"></script>
    <!-- Google Map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
    <script src="/plugins/google-map/gmap.js"></script>

    <script src="/plugins/validate.js"></script>
    <script src="/plugins/wow.js"></script>
    <script src="/plugins/jquery-ui.js"></script>
    <script src="/plugins/timePicker.js"></script>
    <script src="/js2/script.js"></script>


    <footer class="page-footer font-small blue pt-4" style="position:relative;top:100%;height:30%;background-color:#1d3b58!important">
    <br/>
    <img class="rounded mx-auto d-block"  src="/css/logo.png" alt="">  <br/>

        <p   class="text-center  text-white">Endereço: Rua Barão de Cotegipe, Rio Grande - RS, 96200-290 <br/></p>
        <p class="text-center text-white">Telefone: (53) 3035-5525 <br/></p>

        <!-- /.container -->
    </footer>
    <div class="modal fade" id="ExemploModalCentralizado" tabindex="-1" role="dialog" aria-labelledby="TituloModalCentralizado" aria-hidden="true">
    <div  class="modal-dialog modal-dialog-centered" role="document">
        <div style="background-color:#212529;color:white;" class="modal-content">
            <div class="modal-header">
            <h1 style="position:relative;left:25%;font-size:2.5rem;" class="modal-title" id="TituloModalCentralizado">Acesse sua conta!</h1>
            <button  style="border-radius:10%;top:0.2em;height:6%;background-color:white;" type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
            <?php
            if ($this->session->flashdata('error')) {
            ?>
                <div class="alert alert-danger text-center" style="margin-top:20px;font-size:2rem">
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
                <?php
            }
        ?> 
            <form class="form-signin" style="position:relative;font-size:1.8rem;" action="/index.php/Control/logar" method="POST">
                <div class="form-label-group">
                <label for="inputEmail">Email</label>                        
                <input type="email"  id="email2" name="email" class="form-control" placeholder="Email" required>
                </div>
                <br/>
                <div class="form-label-group">
                <label for="inputPassword">Senha</label> 
                <input type="password" id="senha2"  name="senha" class="form-control" placeholder="Senha" required >
                </div>
                <br/>
                <button  class="btn btn-ms btn-primary btn-block text-uppercase" style="position:relative;left:25%;
                border-radius: 15px;width:50%;font-size:1.8rem;" 
                type="submit">Logar</button>  
                <br/>
                <hr style="background-color:blue;" class="my-4">
                <a id="cad3" href="/index.php/Control/formcad" >Não possui conta? Cadastre-se</a>        
                </div>
 
            </form>
            </div>
        </div>
        </div>
    </div>
</body>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
AOS.init();
</script>
</html>
