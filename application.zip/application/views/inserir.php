<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
</head>

<style>

body  {  	
	margin: 0;  	
	padding: 0;  	
	background: #E6E6FA;  
}  
table {
  position: relative;
  border-collapse: collapse;
  border: 1px solid black;  
  width: 80%;
  left: 10%;  
}

td {
  height: 50px;
}
table,tr,td,th {
  position: relative;  
  border: 1px solid black;
  color: black;
  border-color: #0E131E;
  text-align: center;
  height:4em;    
  outline: none;    
  
}
table {
  position: relative;  
  top:-12em;
}
.cadastrar{
	position: relative;
	text-decoration: none;
	top:-1.5em;
	outline: none;
	color:black;
	left: 50%;
}
.cadastrar a{
	outline: none;
	color:black;
}
.topnav {
  background-color: #333;
  overflow: hidden;
  
}

.topnav a {
  float: left;
  color: #f2f2f2;
  margin: 14px;
  text-align: center;
  font-family: 'Franklin Gothic Medium';
  padding: 23px 35px;
  text-decoration: none;
  font-size: 20px;
  margin: 0 0 0 0;
  border-radius:7px;
  
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
  font-size: 22px;  
  border: 1px solid black;
  border: 5px solid #2B8395;;
  border-radius:7px;
  
}

.topnav a.active {
  position: relative;
  background-color:#2B8395;
  margin:0 0 0 0;
  border: 1px solid black;  
  color: white;
}


.dropdown {
  float: left;
  left: 20%;
  padding: 23px 55px ;  
  overflow: hidden;
  
}

.dropdown .dropbtn {
  font-size: 19px;    
  font-family: 'Franklin Gothic Medium';  
  border: none;
  outline: none;
  color: white;
  background-color: #333;
  margin: 0;
  
}

.dropdown-content {
  display: none;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);  
  z-index: 1;
  border-radius:7px;
  
  
  
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}


.dropdown-content a:hover {
  transform: scale(1.0);
  font-size: 20px;  
  background-color: #ddd;
  color: black;
}

.dropdown:hover {
  color: black;
  border: 2px solid #2B8395;;
  border-radius:7px;
  
}

.dropdown:hover .dropdown-content {
  display: block;
  background-color: #ddd;  
  position: absolute;
  
}
button {
  border-radius: 8px;
  border: 0.1em solid black;
  font-family: 'Franklin Gothic Medium';
  font-size: 1.2em;
  outline: none;
  color:black;
  background-color:#F7F7F7;
}
.form {
  position: relative;
  left: 25%;
  top:5em;
  padding: 30px 40px 1px;
  width: 45%;
  height: 25em;
  border-style: groove;
  background-color:white;
  border-radius: 10% 10% 5% 5%;
  display: block;
}

.grupo1 {
  position: relative;
  top:1em;
  display: inline;
}
.grupo2 {
  position: relative;
  top:2em;  
  display: inline;
}
.buttonform {
  position: relative;
  top:4em;
  
}
input {
  border: none;
  width: 50%;
  border-bottom: 1px solid black;  
  font-size: 1.2em;  
  font-family: Impact;
}
input:-webkit-autofill, textarea:-webkit-autofill, select:-webkit-autofill {
  background-color: rgb(35, 16, 109);
  background-image: none;
  font-size: 15px;  
  color: rgb(0, 0, 0);
}
label {
  font-size: 20px;
}
.pagina{
  position: relative;
}
a:link {
  text-decoration:none; 
  color: #19009A
}
select {
  background-color: white;
  font-size: 1.2em;  
  font-family: Impact;
}
</style>
<body>
   <div class="topnav">
		<a class="active" href="#home">Home</a>
		<div class="dropdown">
			<button class="dropbtn">Imóvel 
				<i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
			    <?php if ($_SESSION['tipo_usuario'] == "sim"){ ?>
					<a href="/index.php/Welcome/fpdf">Gerar PDF</a>
					<a href="/index.php/Welcome/inserir">Inserir</a>
				<?php } ?>
				<a  href="/index.php/Welcome/consultar">Pesquisar</a>
				<a  href="/index.php/Welcome/listar">Listar</a>
			</div>
		</div> 
		<div class="dropdown">
			<button class="dropbtn">Perfil 
				<i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
				<a  href="/index.php/Welcome/logout">Logout</a>
			</div>
		</div> 
	</div>
	<div class="form"> 
	<h1>Inserir Imóvel</h1>
	<form action="/index.php/Welcome/salvar" enctype="multipart/form-data" method="post" >
		<label for="">Descrição</label>
		<input name="descricao"><br/><br/>
		<label for="">Foto</label>
		<input type="file" name="foto"><br/><br/>
        <label for="">Bairro</label>
        <input name="bairro" type="text"><br/><br/>
		<label for="">Tipo de operação</label>
		<select name="tipo_operacao" id="">
			<option value="aluguel">Aluguel</option>
			<option value="venda">Venda</option>
		</select><br/><br/>
		<label for="">Número de dormitórios</label>
		<input type="number" name="dormitorios"><br/><br/>
		<label for="">Preço</label>
		<input type="number" step="0.01"name="preco"><br/><br/>
		<button type="submit">Enviar</button>
	</form>
</div>

</body>
</html>
