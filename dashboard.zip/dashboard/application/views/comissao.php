<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("layout/navbar.php");
?>
<div class="container">
<br/>
<h1>Comissão</h1>
<div style="display:none;" id="alert" class="alert alert-success" role="alert">
    Dados salvos com sucesso!
</div>
<div class="card">
<div class="container">
    </br>
    <h5>Nome: <? echo $nome[0]->nome;?>  </h5>
    <h5 style="position:relative;" id="repasse"></h5> 
    <p style="display:none;" id='res'></p>
    <?php
        if ($this->session->flashdata('success')) {
        ?>
            <div class="alert alert-success text-center" style="margin-top:20px;">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
            <?php
        }
    ?> 
    <select name="" style="position:relative;width:30%;" class="form-control" id="select">
        <option value="">Selecione uma data</option>
    <? foreach($datas as $data){ 
        $data = substr($data->data,5,2).'-'.substr($data->data,0,4);?>
        <option value="<?= $data; ?>"><?= $data; ?></option>
    <?}; ?>
    </select>
    <br/>
    <br/>
    <br/>

    <h5 id='total'>Total:</h5>
    <table class="table"  style="position:relative;top:1em;width:40%;">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Descrição</th>
        <th scope="col">Valor</th>
        <th scope="col">Cancelar</th>

        </tr>
    </thead>
    <tbody id="tbody">

    </tbody>
    </table>
    <div class="card" style="position:absolute;height:20em;padding:1rem;left:50%;top:1.5em;width:35%;">
        <p id="parag" style="color:red;display:none;"> Todos os campos são requeridos</p>
        <div class="form-row">
            <div class="form-group col-md-12">
                <label for="inputEmail4">Descrição</label>
                <input type="name" name="descricao" class="form-control" id="desc" id="inputEmail4" placeholder="Descrição">
            </div>
        </div>
        <br/>
        <div class="form-row">
            <div class="form-group col-md-12">
                <label for="inputPassword4">Valor</label>
                <input type="number" class="form-control" id="valor"  name="valor" placeholder="valor">
            </div>
        </div>
        <button style="position:relative;width:10%;top:1.5em" id="aumentar" class="btn btn-primary">+</button><br/>
        <button style="position:relative;left:12%;top:-2.2em;width:10%;" id="diminuir" class="btn btn-danger">-</button><br/>
    </div>
    <br/>
    <button class="btn btn-success" onclick="salvar()" value="Salvar">
    Salvar
    </button>

</div>
</div>
</br>
</br>

</div>
<script src="/js/requisicaocon.js"></script>

<script>
localStorage.clear();
var select = document.getElementById("select");
    $("#select").change(function(){
        if (select.options[select.selectedIndex].value!="null") {
            var data = select.options[select.selectedIndex].value;  
            var d = data.substring(3, 7)+'-'+data.substring(0, 2)+'-01'; 
            var id=<? echo json_encode($_GET['id']) ?>;
            console.log(d);
            requisicao(id,d);
        }
    });
    document.getElementById('aumentar').addEventListener('click',function () {
        p = document.getElementById('parag');
        desc = document.getElementById('desc').value;
        valor = document.getElementById('valor').value;

        if (desc=="" || valor=="") {
            p.style.display = "block";
        }
        else {
            p.style.display = "none";
 
            vetor = { 
                'descricao':desc,
                'valor':valor,
                'operacao':'+'
            };
        
            if (localStorage.getItem("comissao") != null ){
                matriz = [];
                m = JSON.parse(localStorage.getItem('comissao'));
                if(matriz[0] == undefined){
                    matriz.push(m);
                    matriz.push(vetor);
                }
                else {
                    matriz[0].push(m);
                    matriz[0].push(vetor);
                }
                localStorage.setItem('comissao',JSON.stringify(matriz));
                matrizf =JSON.parse(localStorage.getItem("comissao"));
                $('#tbody').empty();
                tbody = document.querySelector('tbody');
                var j=0;
                var valores = 0;

                for (var j = 0; j < matrizf.length; j++) {
                    var tr = document.createElement('tr');
                    var tdvalor = document.createElement('td');
                    var tdesc = document.createElement('td');
                    var tmais = document.createElement('td');
                    var tbutton = document.createElement('td');
                    var button = document.createElement('button');
                    tbutton.appendChild(button);
                    button.textContent = 'Deletar';
                    button.id = j;
                    button.setAttribute("class", "btn btn-danger");
                    button.setAttribute('onclick','excluir();'); // for FF
                    tr.id = j;
                    tmais.textContent = matrizf[j].operacao;
                    tdvalor.textContent = matrizf[j].valor;
                    tdesc.textContent = matrizf[j].descricao;
                    tr.appendChild(tmais);
                    tr.appendChild(tdesc);
                    tr.appendChild(tdvalor);
                    tr.appendChild(tbutton);
                    tbody.appendChild(tr);
                    valor = $("td:nth-child(3)");
                    operacao = $("td:nth-child(1)");
                    var total=0;
                    var valores = 0;
                    for (var i = 0; i <valor.length; i++) {
                        if (operacao[i].textContent == '+') {
                            valores += parseFloat(valor[i].textContent);
                        }
                        else {
                            valores -= parseFloat(valor[i].textContent);
                        }

                    }
                    total += parseFloat(document.getElementById('res').textContent)*0.8491;
                    total += valores;

                }
                document.getElementById('total').innerHTML = 'Total: R$'+total.toFixed(2);

            }
            else {
 
                vetor = { 
                    'descricao':desc,
                    'valor':valor,
                    'operacao':'+'
                };                
                localStorage.setItem('comissao',JSON.stringify(vetor));
                matrizf =JSON.parse(localStorage.getItem("comissao"));
                $('#tbody').empty();
                var total =0;
                var valores = 0;
                tbody = document.querySelector('tbody');
                console.log("tamanho:"+matrizf.length);
                    var tr = document.createElement('tr');
                    var tdvalor = document.createElement('td');
                    var tdesc = document.createElement('td');
                    var tmais = document.createElement('td');
                    tr.id = "1";
                    tmais.textContent = matrizf.operacao;
                    tdvalor.textContent = matrizf.valor;
                    tdesc.textContent = matrizf.descricao;
                    tr.appendChild(tmais);
                    tr.appendChild(tdesc);
                    tr.appendChild(tdvalor);
                    tbody.appendChild(tr);
                    valor = $("td:nth-child(3)");
                    operacao = $("td:nth-child(1)");
                    for (var j = 0; j <valor.length; j++) {
                        if (operacao[j].textContent == '+') {
                            valores += parseFloat(valor[j].textContent);
                        }
                        else {
                            valores -= parseFloat(valor[j].textContent);
                        }
                    }
                    total += document.getElementById('res').textContent*0.8491;
                    total += valores;


            console.log("Valores:"+valores);
            console.log("Total:"+total);

        }
        t = total.toFixed(2);
        document.getElementById('total').innerHTML = 'Total: R$'+t;

    }
    })

    document.getElementById('diminuir').addEventListener('click',function () {
        p = document.getElementById('parag');
        desc = document.getElementById('desc').value;
        valor = document.getElementById('valor').value;

        if (desc=="" || valor=="") {
            p.style.display = "block";
        }
        else {
            p.style.display = "none";
    
            vetor = { 
                    'descricao':desc,
                    'valor':valor,
                    'operacao':'-'
                };  
        
            if (localStorage.getItem("comissao") != null ){
                matriz = JSON.parse(localStorage.getItem('comissao'));
                matriz.push(vetor);
                localStorage.setItem('comissao',JSON.stringify(matriz));
                matrizf =JSON.parse(localStorage.getItem("comissao"));
                $('#tbody').empty();
                tbody = document.querySelector('tbody');
                var j=0;
                for (var j = 0; j < matrizf.length; j++) {
                    var tr = document.createElement('tr');
                    var tdvalor = document.createElement('td');
                    var tdesc = document.createElement('td');
                    var tmais = document.createElement('td');
                    var tbutton = document.createElement('td');
                    var button = document.createElement('button');
                    tbutton.appendChild(button);
                    button.textContent = 'Deletar';
                    button.id = j;
                    button.setAttribute("class", "btn btn-danger");
                    button.setAttribute('onclick','excluir();'); // for FF
                    tr.id = j;
                    tmais.textContent = matrizf[j].operacao;
                    tdvalor.textContent = matrizf[j].valor;
                    tdesc.textContent = matrizf[j].descricao;
                    tr.appendChild(tmais);
                    tr.appendChild(tdesc);
                    tr.appendChild(tdvalor);
                    tr.appendChild(tbutton);
                    tbody.appendChild(tr);
                    valor = $("td:nth-child(3)");
                    operacao = $("td:nth-child(1)");
                    total=0;
                    valores = 0;
                    for (var i = 0; i <valor.length; i++) {
                        if (operacao[i].textContent == '+') {
                            valores += parseFloat(valor[i].textContent);
                        }
                        else {
                            valores -= parseFloat(valor[i].textContent);
                        }

                    }
                    total += parseFloat(document.getElementById('res').textContent)*0.8491;
                    total += valores;

                }
                total = total.toFixed(2);
                document.getElementById('total').innerHTML = 'Total: R$'+total;

            }
            else {
                vetor = [vetor];
                localStorage.setItem('comissao',JSON.stringify(vetor));
                matrizf =JSON.parse(localStorage.getItem("comissao"));
                $('#tbody').empty();
                var total =0;
                tbody = document.querySelector('tbody');
                for (var i = 0; i <= matrizf.length; i++) {
                    var tr = document.createElement('tr');
                    var tdvalor = document.createElement('td');
                    var tdesc = document.createElement('td');
                    var tmais = document.createElement('td');
                    tr.id = i;
                    tmais.textContent = matrizf[i].operacao;
                    tdvalor.textContent = matrizf[i].valor;
                    tdesc.textContent = matrizf[i].descricao;
                    tr.appendChild(tmais);
                    tr.appendChild(tdesc);
                    tr.appendChild(tdvalor);
                    tbody.appendChild(tr);
                    valor = $("td:nth-child(3)");
                    operacao = $("td:nth-child(1)");
                    valores = 0;
                    for (var i = 0; i <valor.length; i++) {
                        if (operacao[i].textContent == '+') {
                            valores += parseFloat(valor[i].textContent);
                        }
                        else {
                            valores -= parseFloat(valor[i].textContent);
                        }
                    }
                    total += parseFloat(document.getElementById('res').textContent)*0.8491;
                    total += valores;


            }
            console.log("Valores:"+valores);
            console.log("Total:"+total);

        }
        total = total.toFixed(2);
        document.getElementById('total').innerHTML = 'Total: R$'+total;

    }

    })

    function excluir() {
        id = event.target.id;
        var v = [];
        var vetor = [];
        document.getElementById(id).remove();
        valor = $("td:nth-child(3)");
        desc = $("td:nth-child(2)");
        operacao = $("td:nth-child(1)");
        total=0;
        valores = 0;
        for (var i = 0; i <valor.length; i++) {
            if (operacao[i].textContent == '+') {
                valores += parseFloat(valor[i].textContent);
                v = [desc[i].textContent,valor[i].textContent,operacao[i].textContent];
                vetor.push(v);

            }   
            else {
                valores -= parseFloat(valor[i].textContent);
            }

        }
        localStorage.setItem('comissao',JSON.stringify(vetor));
        total += parseFloat(document.getElementById('res').textContent)*0.8491;
        total += valores;
        total = total.toFixed(2);
        document.getElementById('total').innerHTML = 'Total: R$'+total;


    }
    function salvar() {
        var vetor = [];
        var v = [];
        valor = $("td:nth-child(3)");
        desc = $("td:nth-child(2)");
        operacao = $("td:nth-child(1)");
        total=0;
        valores = 0;
        for (var i = 0; i <valor.length; i++) {
            v = [valor[i].textContent,desc[i].textContent,operacao[i].textContent];
            vetor.push(v);

        }
        localStorage.setItem('comissao',JSON.stringify(vetor));
        var data = select.options[select.selectedIndex].value;  
        var d = data.substring(3, 7)+'-'+data.substring(0, 2)+'-01'; 
        var id_assessor=<? echo json_encode($_GET['id']) ?>;
        auxilio(localStorage.getItem('comissao'),id_assessor,d);
    }

</script>

<?php
require_once("layout/footer.php");
?>