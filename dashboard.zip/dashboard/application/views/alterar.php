<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("layout/navbar.php");
?>
<div class="container">
<br/>
<h1>Alterar Conta</h1>
<div class="card">
<div class="container">
    </br>
    <?php
        if ($this->session->flashdata('success')) {
        ?>
            <div class="alert alert-success text-center" style="margin-top:20px;">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
            <?php
        }
    ?> 
    <form method="POST" action="alterar" method="POST" style="margin:30px;">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputEmail4">Nome Completo</label>
                <input type="name" value="<?= $user['nome'] ?>" style="text-transform: uppercase" name="nome" class="form-control" id="inputEmail4" placeholder="Nome completo" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Usuário</label>
                <input type="name" value="<?= $user['usuario'] ?>"  class="form-control"  name="usuario" placeholder="Nome para login" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Código</label>
                <input type="number"  value="<?= $user['id'] ?>" class="form-control" id="inputPassword4" name="id" placeholder="Código do assessor" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Alterar Senha</label>
                <input type="password" class="form-control" id="inputPassword4" name="senha" placeholder="Nova senha">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Cidade</label>
                <select class="form-control" name="cidade" id="">
                    <option value="Rio Grande"  <? if ($user['cidade'] == 'Rio Grande') {?>selected <? }?>>Rio Grande</option>
                    <option value="Pelotas" <? if ($user['cidade'] == 'Pelotas') {?>selected <? }?> >Pelotas</option>
                    <option value="Florianópolis"  <? if ($user['cidade'] == 'Florianópolis') {?>selected <? }?>>Florianópolis</option>

                </select>
            </div>
        </div>
        <input class="btn btn-primary" type="submit" value="Enviar">
    </form>
    <br/>
</div>
</div>
</br>
</br>

</div>

<?php
require_once("layout/footer.php");
?>