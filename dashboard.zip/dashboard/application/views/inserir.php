<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("layout/navbar.php");
?>
<div class="container">
<br/>
<h1>Inserir Dados</h1>
<div class="card">
<div class="container">
    </br>
    <?php
        if ($this->session->flashdata('success')) {
        ?>
            <div class="alert alert-success text-center" style="margin-top:20px;">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
            <?php
        }
    ?> 
    <form method="POST" action="upload" method="POST" enctype="multipart/form-data">
        <label>Arquivo</label>
        <input type="file" name="arquivo"  ><br/><br/>
        <label for="">Data</label>
        <div class="col-6 col-md-4">
            <input class="form-control" name="data" type="date" required><br/>
        </div>
        <input class="btn btn-primary" type="submit" value="Enviar">
    </form>
    <br/>
    <br/>
    <div class="alert alert-danger" role="alert">
        <form method="POST" action="deletarplanilha" method="POST">
                Deletar planilha do mês anterior
            <button type="submit" class="btn btn-danger" >
            Clique aqui
            </button>
        </form>
    </div>
    </div>
    <br/>
</div>
</br>
</br>

</div>

<?php
require_once("layout/footer.php");
?>