<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("layout/navbar.php");
?>
<div class="container">
<br/>
<h1>Cadastro de Usuário</h1>
<div class="card">
<div class="container">
    </br>
    <?php
        if ($this->session->flashdata('success')) {
        ?>
            <div class="alert alert-success text-center" style="margin-top:20px;">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
            <?php
        }
    ?> 
    <form method="POST" action="cadastro" method="POST" style="margin:30px;">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputEmail4">Nome Completo</label>
                <input type="name" style="text-transform: uppercase" name="nome" class="form-control" id="inputEmail4" placeholder="Nome completo">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Usuário</label>
                <input type="name" class="form-control"  name="usuario" placeholder="Nome para login">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Código</label>
                <input type="number" class="form-control" id="inputPassword4" name="id" placeholder="Código do assessor">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="inputPassword4">Cidade</label>
                <select class="form-control" name="cidade" id="">
                    <option value="Rio Grande">Rio Grande</option>
                    <option value="Pelotas">Pelotas</option>
                    <option value="Florianópolis">Florianópolis</option>

                </select>
            </div>
        </div>
        <input class="btn btn-primary" type="submit" value="Enviar">
    </form>
    <br/>
</div>
</div>
</br>
</br>

</div>

<?php
require_once("layout/footer.php");
?>