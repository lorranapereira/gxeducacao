<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("layout/navbar.php");
?>

  <!-- MAIN -->
  <div style="position:relative;width:50%;background-color: rgba(112, 150, 228, 0.07);" class="col">
    <br/>
    <h1>
    Dashboard     <? if($_GET['dash']=='total'){?> Office <? }?>
    </h1>
    <br/>

    <form action="">
    <div class="label">
        <label for=""> <strong>Assessor</strong></label>
        <select class="form-control" name="" id="select">
        <option value="null">Selecione um assessor</option>
        <? if ($_SESSION['admin'] == 'true' ) {?>
        <? foreach ($assessores as $a): ?>
            <option value="<?= $a->id; ?>"><?= $a->nome;?></option>
        <? endforeach ?>
        <? } ?>
        </select>
    </div>
    </form>
    <div class="spinner-border text-primary"  id="loading1" style="position:relative;z-index:2;top:22em;left:50%;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="card">
        <h4 class="card-header">Sow(Oportunidade) </h4>
        <div class="card-body">
            <canvas id="monthChart" width="200" height="100"></canvas>
        </div>
    </div>
    <br/>
    <div class="label">
    <label for=""> <strong>Assessor</strong></label>
    <select class="form-control" name="" id="selectReceita">
    <option value="null">Selecione um assessor</option>
    <? if ($_SESSION['admin'] == 'true' ) {?>
    <? foreach ($assessores as $a): ?>
        <option value="<?= $a->id; ?>"><?= $a->nome;?></option>
    <? endforeach ?>
    <? } else { ?>
        <option value="<?= $_SESSION['id']; ?>"><?= $_SESSION['nome'];?></option>
    <?}?>
    </select>
    </div>
    <div class="spinner-border text-primary" id="loading2" style="position:relative;z-index:2;top:22em;left:50%;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="card">
        <h4 class="card-header">Receita Diária </h4>
        <div class="card-body">
            <canvas id="receitaChart" width="200" height="100"></canvas>
        </div>
    </div>
    <br/>
    <div class="label">
    <label for=""> <strong>Assessor</strong></label>
    <select class="form-control" name="" id="selectreceitapie">
        <option value="null">Selecione um assessor</option>
        <? if ($_SESSION['admin'] == 'true' ) {?>
        <? foreach ($assessores as $a): ?>
            <option value="<?= $a->id; ?>"><?= $a->nome;?></option>
        <? endforeach ?>
        <? } ?>
    </select>
    </div>
    <div class="spinner-border text-primary" id="loading3" style="position:relative;z-index:2;top:22em;left:50%;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="card">
        <h4 class="card-header">Receita por produto </h4>
        <div class="card-body" id="novochart">
            <canvas id="porprodutoChart" width="200" height="100"></canvas>
        </div>
    </div>
    <br/>
    <div class="label">
    <label for=""><strong>Assessor</strong></label>
    <select class="form-control" name="" id="selectcaptacao">
    <option value="null">Selecione um assessor</option>
    <? foreach ($assessores as $a): ?>
        <option value="<?= $a->id; ?>"><?= $a->nome;?></option>
    <? endforeach ?>
    </select>
    </div>
    <div class="spinner-border text-primary" id="loading4" style="position:relative;z-index:2;top:22em;left:50%;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="card">
        <h4 class="card-header">Captação Líquida</h4>
        <div class="card-body">
            <canvas id="captacaoLiquida" width="200" height="100"></canvas>
        </div>
    </div>
    <br/>
    <div class="label">
    <label for=""><strong>Assessor</strong></label>
    <select class="form-control" name="" id="selectnet">
    <option value="null">Selecione um assessor</option>
    <? if ($_SESSION['admin'] == 'true' ) {?>
    <? foreach ($assessores as $a): ?>
        <option value="<?= $a->id; ?>"><?= $a->nome;?></option>
    <? endforeach ?>
    <? } else { ?>
        <option value="<?= $_SESSION['id']; ?>"><?= $_SESSION['nome'];?></option>
    <?}?>
    </select>
    </div>
    <div class="spinner-border text-primary" id="loading5" style="position:relative;z-index:2;top:22em;left:50%;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="card">
        <h4 class="card-header">Net por produto</h4>
        <div class="card-body">
            <canvas id="net" width="200" height="100"></canvas>
        </div>
    </div>

</div>

<script>

var ctx = document.getElementById('monthChart').getContext('2d');
//chart declarado e aplicado
var mensalChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['01', '02', '03', '04', '05', '06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    callback: function(value, index, values) {
                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            }]
        }
    }
});

//chart receita total

var receitactx = document.getElementById('receitaChart').getContext('2d');

var receitaChart = new Chart(receitactx, {
    type: 'bar',
    data: {
        labels: ['01', '02', '03', '04', '05', '06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    callback: function(value, index, values) {
                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    }
                }
            }]
        }
    }
});

//porproduto
var porprodutoctx = document.getElementById('porprodutoChart').getContext('2d');
var porprodutoChart = new Chart(porprodutoctx, {
    type: 'pie',
    data: {
        labels: ['Receita Bovespa', 'Receita Futuros', 'Receita RF Bancários', 'Receita RF Privados', 'Receita RF Públicos '],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    callback: function(value, index, values) {
                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                }
            }]
        }
    }
});

var capctx = document.getElementById('captacaoLiquida').getContext('2d');

var captLiquida = new Chart(capctx, {
    type: 'line',
    data: {
        labels: ['01', '02', '03', '04', '05', '06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    callback: function(value, index, values) {
                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                }
            }]
        }
    }
});


var netctx = document.getElementById('net').getContext('2d');

var net = new Chart(netctx, {
    type: 'pie',
    data: {
        labels: ['Net Financeiro','Net Fundos Imobiliários','Net previdência','Net Renda Fixa','Net Renda Variável','Net Fundos','Net outros'],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    callback: function(value, index, values) {
                        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                }
            }]
        }
    }
});




</script>
<script src="/js/requisicao.js"></script>
<script>
    var url = <?php echo json_encode($_GET['dash']); ?>;
    var select = document.getElementById("select");
    var admin = <?= $_SESSION['admin']; ?>;
    if(url == 'total'){
        var x = document.getElementsByClassName("label");
        var i;
        for (i = 0; i < x.length; i++) {
            x[i].style.display = 'none';
        }
        captacaoTotal();
        receitaPieTotal();
        captacaoLiquidaTotal();
        netbarTotal();
        receitaTotal();
    }
    if(url == 'individual'){
        assessor = <?php echo $_SESSION['id']; ?>;
        var x = document.getElementsByClassName("label");
        var i=0;
        if(admin==false){
            for (i = 0; i < x.length; i++) {
                if (i !=  x.length-2 ){
                    x[i].style.display = 'none';
                }
            }
        }
        captacao(assessor);
        receita(assessor);
        receitaPie(assessor);
        captacaoLiquida(assessor);
        netbar(assessor);
        
    }

    $("#select").change(function(){
        if (select.options[select.selectedIndex].value!="null") {
            var assessor = select.options[select.selectedIndex].value;
            document.getElementById('loading1').style.display = 'block';
            captacao(assessor);

        }
    });
    var selectReceita = document.getElementById("selectReceita");
    $("#selectReceita").change(function(){
        if (selectReceita.options[selectReceita.selectedIndex].value!="null") {
            document.getElementById('loading2').style.display = 'block';
            var assessor = selectReceita.options[selectReceita.selectedIndex].value;
            receita(assessor);
        }
    });
    var selectreceitapie = document.getElementById("selectreceitapie");
    $("#selectreceitapie").change(function(){
        if (selectreceitapie.options[selectreceitapie.selectedIndex].value!="null") {
            document.getElementById('loading3').style.display = 'block';
            var assessor = selectreceitapie.options[selectreceitapie.selectedIndex].value;            
            receitaPie(assessor);
        }
    });
    var selectcaptacao = document.getElementById("selectcaptacao");
    $("#selectcaptacao").change(function(){
        if (selectcaptacao.options[selectcaptacao.selectedIndex].value!="null") {
            document.getElementById('loading4').style.display = 'block';
            var assessor = selectcaptacao.options[selectcaptacao.selectedIndex].value;   
            captacaoLiquida(assessor);
        }
    });
    var selectnet = document.getElementById("selectnet");
    $("#selectnet").change(function(){
        if (selectnet.options[selectnet.selectedIndex].value!="null") {
            document.getElementById('loading5').style.display = 'block';
            var assessor = selectnet.options[selectnet.selectedIndex].value;   
            netbar(assessor);
        }
    });

</script>
 
</div><!-- Main Col END -->
  
</div><!-- body-row END -->


</div><!-- container -->
<?php
require_once("layout/footer.php");
?>