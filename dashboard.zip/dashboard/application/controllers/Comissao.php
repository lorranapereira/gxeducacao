<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comissao extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');					
		$this->load->model('Comissao_model','model');
		

	}
	public function comissao(){
		if ($_SERVER['REQUEST_METHOD'] == "GET"){	
			$value['datas'] = $this->model->datas();
			$value['nome'] = $this->model->selectnome($_GET['id']);
			$this->load->view('comissao',$value);
		}
	}	
	public function requisicao(){
		$id = 'A'.$_POST['id'];
		$value['dados'] = $this->model->selectfinalcomissao($id,$_POST['data']);
		$value['valor'] = $this->model->select($id,$_POST['data']);
		echo json_encode($value);
	}
	public function auxilio(){
		$id = 'A'.$_POST['id_assessor'];
		$auxilio = str_split($_POST['auxilio']);	
		$data = substr($_POST['data'],0,4).substr($_POST['data'],4);	
		$this->model->deletecomissaofinal($id,$data);
		$value['valor'] = $this->model->insertcomissaofinal($id,$_POST['auxilio'],$_POST['data']); 
		echo json_encode($value);		
	}
    public function upload(){
		if ($_SERVER['REQUEST_METHOD'] == "GET"){
			$this->load->view('upload');			
		}
		else{
			$this->model->upload();
			$id_user = $this->model->assessores();
			$lastdata = $this->model->lastdata();
			$matriz = [];
			foreach ($id_user as $id) {
				if($id->assessor!='nulo'){
					$up = $this->model->selecttoup($id->assessor,$lastdata[0]->data);		
					array_push($matriz,$up);
				}							
			}
			foreach ($matriz as $m) {
				$this->model->insertnew($m[0]->assessor,$m[0]->somarepasse,$lastdata[0]->data);
			}				
			$this->session->set_flashdata("success",'Dados inseridos com sucesso!');
			$this->load->view('upload');	
		}
	}

}	

