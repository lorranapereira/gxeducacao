<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Total extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');					
		$this->load->model('Total_model','model');
		

	}
		
	public function receitaTotal(){		
		$matriz = [];		
		for ($i=1; $i <= 31; $i++) { 
            $lista = $this->model->receita_total(date("Y"),date("m"),$i,$_POST['cidade']);
            if($lista == array()){
                $lista = [
                    array('total'=>0)
                ];
            }	
			array_push($matriz,$lista);	
        }
		$receitaTotal['receita_total'] = $matriz;
		echo json_encode($receitaTotal);
	}	
	public function netTotal(){	
		$vetor = [];			
		$lista = $this->model->net_total($_POST['cidade']);
		$lista[0]->rendafixa =  round($lista[0]->rendafixa);
		$lista[0]->imobiliarios =  round($lista[0]->imobiliarios);
		$lista[0]->rendavariavel =  round($lista[0]->rendavariavel);
		$lista[0]->fundos =  round($lista[0]->fundos);			
		$lista[0]->financeiro =  round($lista[0]->financeiro);
		$lista[0]->previdencia =  round($lista[0]->previdencia);
		$lista[0]->outros =  round($lista[0]->outros);
		$vetornet['net_produto'] = $lista;
		
		echo json_encode($vetornet);
	}	
	public function captacaoTotal(){
		$diario1 = [];
		$mensal = [];
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->captacaoTotal(date("Y"),date("m"),$i,$_POST['cidade']);
			array_push($diario1,$lista);			
		}
		$vetor['mensal'] = $diario1;
		echo json_encode($vetor);
	}	

	public function dashboard(){
		$datai = date("Y-m-01");	
		$diario1 = [];
		$mensal = [];
		$vetor['assessores'] = $this->model->lista_assessor();		
		$this->load->view('home',$vetor);	
	}

	public function captacaoLiquidaTotal(){
		$cap = [];				
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->captacao_liquida_total(date("Y"),date("m"),$i,$_POST['cidade']);
			array_push($cap,$lista);			
		}
		$vetor['captacao'] = $cap;
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];		
		echo json_encode($vetor);
    }
    public function equipe(){
        $this->load->view('equipe');
	}
	public function receitapietotal(){
		$diario1 = [];
		$mensal = [];
		$cap = [];
		$lista = $this->model->receita_pie_total($_POST['cidade']);		
		$vetor['captacao'] = $lista;		
		echo json_encode($vetor);
	}


}	

