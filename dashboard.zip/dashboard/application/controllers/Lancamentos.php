<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lancamentos extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');					
		$this->load->model('Lancamentos_model','model');
		

	}

	public function receita(){	
		$matriz = [];
					
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->receita(date("Y"),date("m"),$i,$_POST['id']);
			if($lista == array()){
				$lista = [
					array('total'=>0,'Assessor'=>$_POST['id'])
				];
			 }	
			array_push($matriz,$lista);	

		}
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];
		$receitaTotal['receita_total'] = $matriz;
		$nome = explode(" ", $_SESSION['nome']);		
		$receitaTotal['nome'] = $nome[0];
		echo json_encode($receitaTotal);
	}	
		
	public function receitaTotal(){		
		$matriz = [];		
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->receita_total(date("Y"),date("m"),$i);
			$lista[0]->total =  round($lista[0]->total);
			array_push($matriz,$lista);	
		}
		$receitaTotal['receita_total'] = $matriz;
		echo json_encode($receitaTotal);
	}	
	public function net(){	
		$datai = date("Y-m-01");	
		$vetor = [];			
		$lista = $this->model->net_produto($_POST['id']);
		if($lista == array()){
			$lista = [
				array('rendafixa'=>0,'imobiliarios'=>0,'rendavariavel'=>0,'fundos'=>0,'financeiro'=>0,'previdencia'=>0,'outros'=>0,'Assessor'=>$_POST['id'])
			];
		}	
		$vetornet['net_produto'] = $lista;
		$nome = explode(" ", $_SESSION['nome']);		
		$vetornet['nome'] = $nome[0];
		echo json_encode($vetornet);
	}	
	public function netTotal(){	
		$vetor = [];			
		$lista = $this->model->net_total();
		$lista[0]->rendafixa =  round($lista[0]->rendafixa);
		$lista[0]->imobiliarios =  round($lista[0]->imobiliarios);
		$lista[0]->rendavariavel =  round($lista[0]->rendavariavel);
		$lista[0]->fundos =  round($lista[0]->fundos);			
		$lista[0]->financeiro =  round($lista[0]->financeiro);
		$lista[0]->previdencia =  round($lista[0]->previdencia);
		$lista[0]->outros =  round($lista[0]->outros);
		$vetornet['net_produto'] = $lista;
		
		echo json_encode($vetornet);
	}	
	public function captacaoTotal(){
		$diario1 = [];
		$mensal = [];
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->captacaoTotal(date("Y"),date("m"),$i);
			array_push($diario1,$lista);			
		}
		$vetor['mensal'] = $diario1;
		echo json_encode($vetor);
	}	
	public function captacao(){
		$diario1 = [];
		$mensal = [];
					
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->listadiaria(date("Y"),date("m"),$i,intval($_POST['id']));
			if($lista == array()){
			   $lista = [array('soma'=>0,'Assessor'=>$_POST['id'],'realizado'=>0)];
			}	

			array_push($diario1,$lista);			
		}
		$vetor['assessores'] = $this->model->lista_assessor();		
		$vetor['mensal'] = $diario1;
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];
		echo json_encode($vetor);
	}		
	public function deletarplanilha(){
		$datai = date("Y-m-01");	
		$diario1 = [];
		$mensal = [];
		$msg= $this->model->deletarplanilha(date('m')-1);		
		$this->load->view('home',$vetor);	
	}
	public function dashboard(){
		$datai = date("Y-m-01");	
		$diario1 = [];
		$mensal = [];
		$vetor['assessores'] = $this->model->lista_assessor();		
		$this->load->view('home',$vetor);	
	}

	public function captacaoLiquida(){
		$cap = [];				
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->captacao_liquida(date("Y"),date("m"),$i,$_POST['id']);
			if($lista == array()){
				$lista = [array('total'=>0,'Assessor'=>$_POST['id'])];
			}

			array_push($cap,$lista);			
		}
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];
		$vetor['captacao'] = $cap;		
		echo json_encode($vetor);
	}

	public function captacaoLiquidaTotal(){
		$cap = [];				
		for ($i=1; $i <= 31; $i++) { 
			$lista = $this->model->captacao_liquida_total(date("Y"),date("m"),$i);
			array_push($cap,$lista);			
		}
		$vetor['captacao'] = $cap;
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];		
		echo json_encode($vetor);
	}
	public function receitapietotal(){
		$diario1 = [];
		$mensal = [];
		$cap = [];
		$lista = $this->model->receita_pie_total();		
		$lista[0]->bovespa =  round($lista[0]->bovespa);
		$lista[0]->futuros =  round($lista[0]->futuros);
		$lista[0]->bancarios =  round($lista[0]->bancarios);
		$lista[0]->publicos =  round($lista[0]->publicos);			
		$lista[0]->privados =  round($lista[0]->privados);
		$vetor['captacao'] = $lista;		
		echo json_encode($vetor);
	}
	public function receitapie(){
		$diario1 = [];
		$mensal = [];
		$id_user = $this->model->buscar_id();
		$cap = [];
		$lista = $this->model->receita_pie($_POST['id']);		
		$lista[0]->bovespa =  round($lista[0]->bovespa);
		$lista[0]->futuros =  round($lista[0]->futuros);
		$lista[0]->bancarios =  round($lista[0]->bancarios);
		$lista[0]->publicos =  round($lista[0]->publicos);			
		$lista[0]->privados =  round($lista[0]->privados);
		$vetor['captacao'] = $lista;
		$nome = explode(" ", $_SESSION['nome']);		
		$vetor['nome'] = $nome[0];			
		echo json_encode($vetor);
	}
	public function upload(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$this->model->upload();	
			header('Location:verifica');
		}
		else{
			$this->load->view('inserir');		 
			
		}
		
	}	
	
	public function verifica() {
		$id_user = $this->model->buscar_id();		
		foreach ($id_user as $id) {
			$lista = $this->model->relistadiaria($id->Assessor);				
			$this->model->insertIndividual($lista);	
					
		}
		$data = $this->model->ultimoUpload();
		$this->model->deletarplanilha($data['data']);	
		$this->session->set_flashdata("success",'Dados inseridos com sucesso!');
		$this->load->view('inserir');			
		
	}


}	

