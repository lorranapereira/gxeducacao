<?php

class Usuario_model extends CI_Model{


/*    public function inserirUser($obj){
        $email = $obj['email'];
        $query = $this->db->query("SELECT * FROM usuario WHERE email='".$email."'");
        if ($query->result() != NULL){
            return "Este email já foi registrado!";            
        }      
        else {
            $this->db->insert('usuario',$obj);   
            return "Cadastro realizado com sucesso!";            
        }

    }*/
    public function lista(){     
        $query = $this->db->query("SELECT *FROM assessor");   
        return $query->result();
    }
    public function cadastrar($nome,$usuario,$id,$city){     
        $query = $this->db->query("SELECT * FROM assessor WHERE usuario='".$usuario."'");
        if ($query->result() != NULL){
            return "Ops! Esse nome para login já foi registrado.";            
        }      
        else {
            $query = $this->db->query("INSERT INTO assessor(nome,usuario,id,cidade) VALUES('$nome','$usuario','$id','$city')");   
            return "Cadastro realizado com sucesso!";            
        }
    }
    public function verificarUser($nome,$senha){     
        $query = $this->db->get_where('assessor', array('usuario'=>$nome,'senha'=>$senha));
        return $query->row_array();
    }
    
    public function buscar($id){     
        $query = $this->db->get_where('assessor', array('id'=>$id));
        return $query->row_array();
    }
    public function alterar($obj){     
        $this->db->where('id', $obj['id']);        
        $this->db->set($obj);        
        $this->db->update('assessor',$obj);  
        return "Seus dados foram  alterados com sucesso!";            
    }

    public function deletar($id){     
        $query = $this->db->query("DELETE from assessor  WHERE id = '".$id."'  ");
        return "Usuário deletado!";
    }

    
    
 
}

?>
