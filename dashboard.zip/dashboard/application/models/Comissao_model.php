<?php

class Comissao_model extends CI_Model{
 
    public function upload(){                 
        //$dados = $_FILES['arquivo'];
        //var_dump($dados);
        
        if(!empty($_FILES['arquivo']['tmp_name'])){
            $arquivo = new DomDocument();
            $arquivo->load($_FILES['arquivo']['tmp_name']);
            //var_dump($arquivo);
            
            $linhas = $arquivo->getElementsByTagName("Row");
            //var_dump($linhas);
            
            $i = 0;
            $num = $linhas->length;
            foreach($linhas as $linha){
                if($i>=3){
                $data = $linha->getElementsByTagName("Data")->item(0)->nodeValue;
                $data = substr($data,0,4).'-'.substr($data,4).'-01';
                $assessor = $linha->getElementsByTagName("Data")->item(10)->nodeValue;
                $repasse = $linha->getElementsByTagName("Data")->item(9)->nodeValue;                
                $repasseAssessor= $linha->getElementsByTagName("Data")->item(12)->nodeValue;                 
                $query = $this->db->query("INSERT INTO `comissao`(                       
                `assessor`,
                `repasseAssessor`,
                `data`) VALUES (
                    '".$assessor."',
                    '".$repasseAssessor."',
                    '".$data."'
                    )");
                }
                $i += 1;  
            }
        }
        return "Dados inseridos com sucesso!";  
                
    }
    public function deletecomissaofinal($id,$data){
        $query = $this->db->query("DELETE FROM `finalcomissao` WHERE id_assessor='$id' and data='$data'");
        return "Deletado com sucesso";       
    }   
    public function selectnome($id){
        $query = $this->db->query("SELECT nome FROM assessor WHERE id='$id'");
        return $query->result();        
    } 
    public function assessores(){
        $query = $this->db->query("SELECT DISTINCT assessor FROM comissao");
        return $query->result();        
    } 
    public function lastdata(){
        $query = $this->db->query("SELECT max(date(data)) as data FROM `comissao` LIMIT 1");
        return $query->result();        
    } 
    public function datas(){
        $query = $this->db->query("SELECT DISTINCT data FROM `plancomissao`");
        return $query->result();        
    } 
    public function insertnew($id,$con,$data){
        $query = $this->db->query("INSERT INTO `plancomissao`(                       
            `assessor`,
            `repasseAssessor`,
            `data`) VALUES (
                '".$id."',
                '".$con."',
                '".$data."'
                )");
        
    }  
    public function selectcomissaofinal($assessor,$auxilio,$data){
        $query = $this->db->query("SELECT `repasseAssessor` as repasse, assessor from plancomissao where data ='$data' and assessor = '$id' LIMIT 1");
        return $query->result();        
        
    }
    public function selectfinalcomissao($id,$data){
        $query = $this->db->query("SELECT *from `finalcomissao` where data ='$data' and id_assessor = '$id'");
        return $query->result();        
        
    }
    public function insertcomissaofinal($assessor,$auxilio,$data){
        $auxilio = json_decode($auxilio);
        foreach ($auxilio as $a) {
            $operacao = $a[2];
            $des = $a[1];
            $valor = $a[0];
            $query = $this->db->query("INSERT INTO `finalcomissao`(                       
                `descricao`,
                `operacao`,
                `valor`,
                `id_assessor`,
                `data`) VALUES (
                    '".$des."',
                    '".$operacao."',
                    '".$valor."',
                    '".$assessor."',
                    '".$data."'
                    )");
            
        }
        return "Enviado com sucesso!";
    }
    public function select($id,$data){
        $query = $this->db->query("SELECT `repasseAssessor` as repasse, assessor from plancomissao where data ='$data' and assessor = '$id' LIMIT 1");
        return $query->result();        
        
    }  
    public function selecttoup($id,$data){
        $query = $this->db->query("SELECT Coalesce(sum(`repasseAssessor`)) as somarepasse, assessor from comissao where data ='$data' and assessor = '$id'");
        return $query->result();        
        
    }
}


?>
