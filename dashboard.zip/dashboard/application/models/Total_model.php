<?php

class Total_model extends CI_Model{

    public function relistadiaria($id) {
        $query = $this->db->query("SELECT Coalesce(sum(AplicaçãoFinanceiraDeclarada),0) as soma,Coalesce(sum(NetEmM),0) as realizado, Coalesce(sum(ReceitanoMes),0) as total, Coalesce(sum(ReceitaBovespa),0) as bovespa, Coalesce(sum(ReceitaFuturos),0) as futuros,Coalesce(sum(ReceitaRFBancários),0) as bancarios, Coalesce(sum(ReceitaRFPublicos),0) as publicos, Coalesce(sum(ReceitaRFPrivados),0) as privados,data,Assessor,Coalesce(sum(NetRendaFixa),0) as rendafixa, Coalesce(sum(NetFundosImobiliarios),0) as imobiliarios,Coalesce(sum(NetRendaVariavel),0) as rendavariavel,Coalesce(sum(NetFundos),0) as fundos,Coalesce(sum(NetFinanceiro),0) as financeiro, Coalesce(sum(NetPrevidencia),0) as previdencia,  Coalesce(sum(NetOutros),0) as outros, Coalesce(sum(CaptacaoBrutaemM),0) as 'captacaobruta' FROM `assessorCliente` WHERE `Assessor` = '".$id."' and date(data) IN (SELECT max(date(data)) FROM `assessorCliente` group by `Assessor`)"); 
        return $query->result();
    }      
    
    public function captacaoTotal($ano,$mes,$dia,$city) {
        $query = $this->db->query("SELECT Coalesce(sum(aplicado),0) as soma, Coalesce(sum(realizado),0) as realizado     from grafico inner join assessor on grafico.id = assessor.id WHERE cidade ='".$city."' and year(data) = '".$ano."' and month(data) = '".$mes."' and day(data) = '".$dia."' ");   
        return $query->result();       
    }
    public function receita_total($ano,$mes,$dia,$city){     
        $query = $this->db->query("SELECT  Coalesce(sum(receitadiaria),0) as total FROM `grafico` inner join assessor on  grafico.id = assessor.id  WHERE cidade='".$city."' and year(data) = '".$ano."' and month(data) = '".$mes."' and day(data) = '".$dia."'");
        return $query->result();
    }
    
    public function receita_pie_total($city){     
        $query = $this->db->query("SELECT Coalesce(sum(receitabovespa),0) as bovespa, Coalesce(sum(receitafutura),0) as futuros,Coalesce(sum(receitabancaria),0) as bancarios, Coalesce(sum(receitapublica),0) as publicos, Coalesce(sum(receitaprivada),0) as privados FROM  `grafico` inner join assessor on  grafico.id = assessor.id  WHERE cidade='".$city."' and date(data) IN (SELECT max(date(data)) FROM `grafico`)");
        return $query->result();
    }
    public function net_total($city){    
        $query = $this->db->query("SELECT Coalesce(sum(netfixa),0) as rendafixa, Coalesce(sum(netimobiliario),0) as imobiliarios,Coalesce(sum(netvariavel),0) as rendavariavel,Coalesce(sum(netfundos),0) as fundos,Coalesce(sum(netfinanceiro),0) as financeiro, Coalesce(sum(netprevidencia),0) as previdencia,  Coalesce(sum(netoutros),0) as outros FROM `grafico` inner join assessor on grafico.id = assessor.id WHERE cidade ='".$city."' and date(data) IN (SELECT max(date(data)) FROM `grafico`)");
        return $query->result();
    }
    public function captacao_liquida_total($ano,$mes,$dia,$city){     
        $query = $this->db->query("SELECT Coalesce(sum(captacaoliquida),0) as total from `grafico`  inner join assessor on grafico.id = assessor.id WHERE cidade ='".$city."' and year(data) = '".$ano."' and month(data) = '".$mes."' and day(data) = '".$dia."'");
        return $query->result();
    }
}


?>
